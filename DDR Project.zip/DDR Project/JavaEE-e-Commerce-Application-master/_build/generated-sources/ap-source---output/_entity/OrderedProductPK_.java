package entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="EclipseLink-2.5.1.v20130918-rNA", date="2014-05-27T11:43:39")
@StaticMetamodel(OrderedProductPK.class)
public class OrderedProductPK_ { 

    public static volatile SingularAttribute<OrderedProductPK, Integer> customerOrderId;
    public static volatile SingularAttribute<OrderedProductPK, Integer> productId;

}